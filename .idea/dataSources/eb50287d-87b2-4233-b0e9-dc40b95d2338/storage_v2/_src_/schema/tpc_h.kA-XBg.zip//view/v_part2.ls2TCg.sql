create definer = `skip-grants user`@`skip-grants host` view v_part2 as
select `c`.`C_CUSTKEY`         AS `custkey`,
       max(`c`.`C_NAME`)       AS `cname`,
       avg(`o`.`O_TOTALPRICE`) AS `avgprice`,
       avg(`l`.`L_QUANTITY`)   AS `avgquantity`
from `tpc_h`.`customer` `c`
         join `tpc_h`.`orders` `o`
         join `tpc_h`.`lineitem` `l`
where ((`c`.`C_CUSTKEY` = `o`.`O_CUSTKEY`) and (`l`.`L_ORDERKEY` = `o`.`O_ORDERKEY`))
group by `c`.`C_CUSTKEY`;

