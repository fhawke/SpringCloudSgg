create definer = `skip-grants user`@`skip-grants host` view v_part4 as
select `tpc_h`.`partsupp`.`PS_PARTKEY`    AS `PS_PARTKEY`,
       `tpc_h`.`partsupp`.`PS_SUPPKEY`    AS `PS_SUPPKEY`,
       `tpc_h`.`partsupp`.`PS_AVAILQTY`   AS `PS_AVAILQTY`,
       `tpc_h`.`partsupp`.`PS_SUPPLYCOST` AS `PS_SUPPLYCOST`
from `tpc_h`.`partsupp`
where (`tpc_h`.`partsupp`.`PS_SUPPKEY` =
       (select `tpc_h`.`supplier`.`S_SUPPKEY` from `tpc_h`.`supplier` where (`tpc_h`.`supplier`.`S_NAME` = '亚马逊')));

