create definer = `skip-grants user`@`skip-grants host` view v_part as
select `p`.`P_PARTKEY`      AS `P_PARTKEY`,
       `p`.`P_NAME`         AS `P_NAME`,
       `ps`.`PS_AVAILQTY`   AS `PS_AVAILQTY`,
       `p`.`P_RETAILPRICE`  AS `P_RETAILPRICE`,
       `ps`.`PS_SUPPLYCOST` AS `PS_SUPPLYCOST`,
       `p`.`P_COMMENT`      AS `P_COMMENT`
from `tpc_h`.`part` `p`
         join `tpc_h`.`partsupp` `ps`
         join `tpc_h`.`supplier` `s`
where ((`p`.`P_PARTKEY` = `ps`.`PS_PARTKEY`) and (`s`.`S_SUPPKEY` = `ps`.`PS_SUPPKEY`) and (`s`.`S_NAME` = '亚马逊'));

